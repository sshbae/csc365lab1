# csc365lab1
#compile and run the program with:  python schoolsearch.py
#The program imports the Pandas library so this library must be installed